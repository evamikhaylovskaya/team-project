



public class MinCostRope {
    public static int minCostToConnectRopes(int[] ropes) {
        MinHeap minHeap = new MinHeap(ropes.length);
        for (int rope : ropes) {
            minHeap.insert(rope);
        }
        
        int totalCost = 0;
        while (minHeap.size() > 1) {
            int first = minHeap.extractMin();
            int second = minHeap.extractMin();
            int cost = first + second;
            totalCost += cost;
            System.out.println("Connecting the ropes lil bro: " + first + " + " + second + " = " + cost);
            minHeap.insert(cost);
        }
        return totalCost;
    }
    
    public static void main(String[] args) {
        int[] ropes = {4,8,3,1,6,9,12,7,2};
        int result = minCostToConnectRopes(ropes);
        System.out.println("Minimum cost to connect the ropes: " + result);
    }
}

